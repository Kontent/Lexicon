<?php
$gl_utf8 = "0";
$gl_admin_utf8 = "0";
$gl_allowentry = "1";
$gl_defaultcat = "2";
$gl_autopublish = "0";
$gl_notify = "0";
$gl_notify_email = "lexicon@yoursite.com";
$gl_thankuser = "1";
$gl_perpage = "500";
$gl_sorting = "0";
$gl_showrating = "";
$gl_anonentry = "0";
$gl_hideauthor = "0";
$gl_showcategories = "1";
$gl_beginwith = "nothing";
$gl_shownumberofentries = "1";
$gl_showcatdescriptions = "1";
$gl_useeditor = "0";
$gl_show_alphabet = "1";
$gl_strip_accents = "0";
$gl_multieditors = 5; // NICOLAES
?>