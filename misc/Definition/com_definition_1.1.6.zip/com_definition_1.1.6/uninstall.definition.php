<?php
/**
 * Language file
 * @author GranholmCMS
 * @link http://www.granholmcms.com
 */

defined('_JEXEC') or die('Restricted access');

function com_uninstall()
{
echo "Uninstalled - Do visit www.granholmcms.com";
}

?>