<?php
/**
* @package plugin/mambot purecsstooltip
* @version 1.0.1
* @copyright Copyright (C) 2008 Carsten Engel. All rights reserved.
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
* @author http://www.joomlapi.com
* @joomla Joomla is Free Software
*/

//no direct access
if(!defined('_VALID_MOS') && !defined('_JEXEC')){
	die('Restricted access');
}

$mainframe->registerEvent( 'onPrepareContent', 'purecsstooltip' );

function purecsstooltip( &$row, &$params, $page=0 ){			
	
	global $mainframe;

	// Don't repeat the CSS for each instance of this bot in a page!
	static $included_purecsstooltip_css;
	
	if (!$included_purecsstooltip_css) {
		$document =& JFactory::getDocument();
		$url = 'plugins/content/purecsstooltip.css';
		$document->addStyleSheet($url);	
		$document->addCustomTag( '<!--[if lte IE 6]>
		<style type="text/css">
	
			.tooltip:hover span{
				left: auto;
			}
		   
			.tooltip span{           
				left: -9999px;   
			}
		   
		</style>
	<![endif]-->' );	
		$included_purecsstooltip_css = 1;
	}

	$string = $row->text;
	$patterns[0] = '/{tooltip}/';
	$patterns[1] = '/{end-link}/';
	$patterns[2] = '/{end-tooltip}/';
	$replacements[2] = '<a href="#" class="tooltip">';
	$replacements[1] = '<span><span>';
	$replacements[0] = '</span></span></a>';
	
	$row->text = preg_replace($patterns, $replacements, $string);		
	
}

?>