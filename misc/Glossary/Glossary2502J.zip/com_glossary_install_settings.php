<?php

// NOTE These values are used ONLY on installation.  Once installation has
// been done, the configuration information is held in the database.
//
// Set properties of pretty much any kind e.g.
// $this->property = 'some value';
$this->utf8 = "0";
$this->admin_utf8 = "0";
$this->allowentry = "1";
$this->autopublish = "1";
$this->notify = "0";
$this->notify_email = "glossary@yoursite.com";
$this->thankuser = "1";
$this->perpage = "15";
$this->pagespread = "4";
$this->sorting = "";
$this->showrating = "";
$this->anonentry = "0";
$this->hideauthor = "0";
$this->showcategories = "0";
$this->beginwith = "nothing";
$this->shownumberofentries = "1";
$this->showcatdescriptions = "1";
$this->useeditor = "0";
$this->show_alphabet = "1";
$this->strip_accents = "0";
$this->language = "";