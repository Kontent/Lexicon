<----------->
Glossary 2.50 for Joomla 1.5
April 2008
Martin Brampton
<----------->

Complete rewrite.