<?php

/**************************************************************
* This file is part of Glossary
* Copyright (c) 2008 Martin Brampton
* Issued as open source under GNU/GPL
* For support and other information, visit http://remository.com
* To contact Martin Brampton, write to martin@remository.com
*
* More details in glossary.php
*/

class listEntriesHTML extends cmsapiAdminHTML {
	var $site = '';

	function listEntriesHTML (&$controller, $limit, $clist) {
		cmsapiAdminHTML::cmsapiAdminHTML($controller, $limit, $clist);
		$interface =& cmsapiInterface::getInstance();
		$this->site = $interface->getCfg('live_site');
	}

	function view ($glossary, $entries, $search) {
		$compname = _THIS_COMPONENT_NAME;
		$cname = strtolower($compname);
		$listing = '';
		foreach ($entries as $i=>$entry) {
			$link = <<<EDIT_LINK
index.php?option=com_$cname&act=entries&task=edit&id=$entry->id
EDIT_LINK;
			$listing .= <<<LIST_ITEM
			
				<tr>
					<td>
						<input type="checkbox" id="cb$i" name="cfid[]" value="$entry->id" onclick="isChecked(this.checked);" />
					</td>
					<td><a href="$link">$entry->tterm</a></td>
					<td>$entry->tletter</td>
					<td><input type="text" size="60" class="inputbox" value="$entry->tdefinition" /></td>
					<td>$entry->tdate</td>
					<td>$entry->published</td>
				</tr>
			
LIST_ITEM;

		}
		$title = _GLOSSARY_LIST_ENTRIES;
		$icon = "../components/com_glossary/images/glosslogo.png";
		$count = count($entries);
		
		$gl_term = _GLOSSARY_TERM;
		$gl_letter = _GLOSSARY_LETTER;
		$gl_definition = _GLOSSARY_DEFINITION;
		$gl_date = _GLOSSARY_DATE;
		$gl_published = _GLOSSARY_PUBLISHED;
		
		echo <<<GLOSSARY_HEAD
		
		<div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
		<script type="text/javascript" src="../includes/js/overlib_mini.js"></script>
		<form action="index2.php" method="post" name="adminForm">
		<table cellpadding="4" cellspacing="0" border="0" width="100%">
   		<tr>
			<td width="75%" colspan="3">
			<div class="title header">
				<img src="$icon"> 
				<span class="sectionname">&nbsp;$compname $title</span>
			</div>
			</td>
			<td width="25%">
			</td>
    	</tr>
    	</table>
		<table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminlist">
			<thead>
				<tr>
					<th width="5" align="left">
						<input type="checkbox" name="toggle" value="" onclick="checkAll($count);" />
					</th>
					<th>$gl_term</th>
					<th>$gl_letter</th>
					<th>$gl_definition</th>
					<th>$gl_date</th>
					<th>$gl_published</th>
				</tr>
			</thead>
			
GLOSSARY_HEAD;

		$this->pageNav->listFormEnd('com_'.$cname);
		echo <<<GLOSSARY_LIST
		
			<tbody>
				$listing
			</tbody>
		</table>
		</form>
				
GLOSSARY_LIST;

	}
}