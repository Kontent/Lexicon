<?php

class glossaryAdminEntries extends cmsapiAdminControllers {

	function listTask () {
		$database = $this->interface->getDB();
		$database->setQuery("SELECT COUNT(*) FROM #__glossary");
		$total = $database->loadResult();
		$database->setQuery("SELECT * FROM #__glossary LIMIT {$this->admin->limitstart}, {$this->admin->limit}");
		$glossaries = $database->loadObjectList();
		if (!$glossaries) $glossaries = array();
		// Create and activate a View object
		$view = $this->admin->newHTMLClassCheck ('listEntriesHTML', $this, $total, '');
		$view->view($container, $glossaries, $search);
	}
	
	function editTask () {
		$database = $this->interface->getDB();
		$entry = new glossaryEntry($database);
		if ($this->idparm) $entry->load($this->idparm);
		$database->setQuery("SELECT * FROM #__glossaries");
		$glossaries = $database->loadObjectList();
		// Create and activate a View object
		$view = $this->admin->newHTMLClassCheck ('editEntriesHTML', $this, 0, '');
		$view->edit($entry, $glossaries);
	}
	
	function addTask () {
		$this->editTask();
	}
	
	function saveTask () {
		$database = $this->interface->getDB();
		$entry = new glossaryEntry($database);
		$entry->published = 0;
		$entry->bind($_POST);
		$entry->save();
		$this->interface->redirect("index2.php?option=com_glossary&act=entries");
	}
	
	function deleteTask () {
		$database = $this->interface->getDB();
		$cfid = $this->interface->getParam($_REQUEST, 'cfid', array());
		foreach ($cfid as $key=>$value) $cfid[$key] = intval($value);
		$idlist = implode(',', $cfid);
		if ($idlist) {
			$database->setQuery("DELETE FROM #__glossary WHERE id IN ($idlist)");
			$database->query();
		}
		$this->interface->redirect("index2.php?option=com_glossary&act=entries");
	}
	
	function publishTask () {
		$cfid = $this->interface->getParam($_REQUEST, 'cfid', array());
		$this->publishToggle('#__glossary', $cfid, 1);
		$this->interface->redirect("index2.php?option=com_glossary&act=entries");
	}

	function unpublishTask () {
		$cfid = $this->interface->getParam($_REQUEST, 'cfid', array());
		$this->publishToggle('#__glossary', $cfid, 0);
		$this->interface->redirect("index2.php?option=com_glossary&act=entries");
	}

}