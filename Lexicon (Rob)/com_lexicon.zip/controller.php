<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

/**
 * Base controller class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconController extends JController
{
	/**
	 * Method to display a view.
	 *
	 * @access	public
	 * @return	void
	 * @since	1.0
	 */
	function display()
	{
		// Get the current URI to redirect to.
		$uri		= &JURI::getInstance();
		$redirect	= $uri->toString();
		$redirect	= base64_encode($redirect);

		// Check for the JXtended Libraries.
		if (!file_exists(JPATH_SITE.'/plugins/system/jxtended.php')) {
			JError::raiseWarning(500, JText::sprintf('JX_LIBRARIES_MISSING', $redirect, JUtility::getToken()));
			JHTML::script('setup.js', 'administrator/components/com_labels/media/js/');
		}
		elseif (!function_exists('jximport')) {
			// Attempt to enable the libraries.
			$setup	= &$this->getModel('Setup');
			$return	= $setup->enableLibraries();

			if ($return === false) {
				// We couldn't enable the libraries plugin so throw a warning.
				JError::raiseWarning(500, JText::sprintf('JX_LIBRARIES_DISABLED', $redirect, JUtility::getToken()));
				JHTML::script('setup.js', 'administrator/components/com_labels/media/js/');
			} else {
				// Reload the page because we might need the libraries which weren't loaded on this page.
				$this->setRedirect('index.php?option=com_labels');
				return true;
			}
		}
		elseif (version_compare(JX_LIBRARIES,'1.0.8', '<')) {
			JError::raiseWarning(500, JText::sprintf('JX_LIBRARIES_OUTDATED', '1.0.8'));
		}

		// Get the document object.
		$document = &JFactory::getDocument();

		// Set the default view name and format from the Request.
		$vName		= JRequest::getWord('view', 'terms');
		$vFormat	= $document->getType();
		$lName		= JRequest::getWord('layout', 'default');

		$view	= &$this->getView($vName, $vFormat);
		$model	= &$this->getModel($vName);

		// Push the model into the view (as default).
		$view->setModel($model, true);
		$view->setLayout($lName);

		// Push document object into the view.
		$view->assignRef('document', $document);

		$view->display();
	}

	/**
	 * Method to get the appropriate controller.
	 *
	 * @access	public
	 * @return	object	Lexicon Controller
	 * @since	1.0
	 */
	function &getInstance()
	{
		static $instance;

		if (!empty($instance)) {
			return $instance;
		}

		$cmd = JRequest::getCmd('task', 'display');

		// Check for a controller.task command.
		if (strpos($cmd, '.') != false)
		{
			// Explode the controller.task command.
			list($type, $task) = explode('.', $cmd);

			// Define the controller name and path
			$protocol	= JRequest::getWord('protocol');
			$type		= strtolower($type);
			$file		= (!empty($protocol)) ? $type.'.'.$protocol.'.php' : $type.'.php';
			$path		= JPATH_COMPONENT.DS.'controllers'.DS.$file;

			// If the controller file path exists, include it ... else die with a 500 error.
			if (file_exists($path)) {
				require_once($path);
			} else {
				JError::raiseError(500, JText::sprintf('JX_INVALID_CONTROLLER', $type));
			}

			JRequest::setVar('task', $task);
		} else {
			// Base controller, just set the task.
			$type = null;
			$task = $cmd;
		}

		// Set the name for the controller and instantiate it.
		$class = 'LexiconController'.ucfirst($type);
		if (class_exists($class)) {
			$instance = new $class();
		} else {
			JError::raiseError(500, JText::sprintf('JX_INVALID_CONTROLLER_CLASS', $class));
		}

		return $instance;
	}
}