<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die;

jimport('joomla.database.table');

/**
 * Term table class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconTableTerm extends JTable
{
	var $id					= null;

	var $singular			= null;

	var $plural				= null;

	var $body				= null;

	var $state				= null;

	var $created			= null;

	var $created_by			= null;

	var $created_by_alias	= null;

	var $modified			= null;

	var $modified_by		= null;

	var $checked_out		= null;

	var $checked_out_time	= null;

	var $params				= null;

	function __construct(&$db)
	{
		parent::__construct('#__lexicon_terms', 'id', $db);

		$this->id				= 0;
		$this->state			= 1;
		$this->checked_out		= 0;
		$this->checked_out_time	= 0;
	}

	function check()
	{
		// Check for a term.
		if (empty($this->singular)) {
			$this->setError(JText::_('LEXICON_TERM_CHECK_SINGULAR_FAILED'));
			return false;
		}

		return true;
	}

	function checkin($user_id = null, $oid = null)
	{
		$k = $this->_tbl_key;

		if ($user_id === null) {
			$user_id = (int)$this->checked_out;
		}

		if ($oid !== null) {
			$this->$k = $oid;
		}

		if ($this->$k == null) {
			return false;
		}

		$this->$k = (int) $this->$k;

		// Prepare the query to check-in the row.
		$query	= 'UPDATE '.$this->_db->nameQuote($this->_tbl)
				. ' SET checked_out = 0, checked_out_time = '.$this->_db->Quote($this->_db->getNullDate())
				. ' WHERE '.$this->_tbl_key.' = '.(int)($this->$k)
				. ' AND (checked_out = '.(int)$user_id.' OR checked_out = 0)';

		$this->_db->setQuery($query);
		$this->_db->query();

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		$this->checked_out = 0;
		$this->checked_out_time = '';

		return true;
	}

	function checkout($user_id, $oid = null)
	{
		jimport('joomla.utilities.date');

		$k = $this->_tbl_key;

		if ($oid !== null) {
			$this->$k = $oid;
		}

		$this->$k	= (int) $this->$k;
		$user_id	= (int) $user_id;

		// Get a MySQL formatted time.
		$date = new JDate();
		$time = $date->toMysql();

		// Prepare the query to check-out the row.
		$query	= 'UPDATE '.$this->_db->nameQuote($this->_tbl)
				. ' SET checked_out = '.(int)$user_id.', checked_out_time = '.$this->_db->Quote($time)
				. ' WHERE '.$this->_tbl_key.' = '.(int)($this->$k)
				. ' AND (checked_out = '.(int)$user_id.' OR checked_out = 0)';

		$this->_db->setQuery($query);
		$this->_db->query();

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Prepare the query to verify the item was checked-out.
		$query	= 'SELECT id FROM '.$this->_db->nameQuote($this->_tbl)
				. ' WHERE '.$this->_tbl_key.' = '.(int)($this->$k)
				. ' AND checked_out = '.(int)$user_id;

		$this->_db->setQuery($query);
		$return = (int) $this->_db->loadResult();

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		$this->checked_out = $user_id;
		$this->checked_out_time = $time;

		if ($return === $this->$k) {
			return true;
		} else {
			return null;
		}
	}

	/**
	 * Method to delete one or more labels. If label state is not -2 then the label
	 * state will be set to -2. If it is -2, the rows will be deleted from the database.
	 * This allows for a simple recycle bin feature.
	 *
	 * @access	public
	 * @param	array	$oid	An array of integers indicating the rows to delete
	 * @return	boolean	True if successful otherwise returns and error message
	 */
	function delete($id = null)
	{
		if ($id !== null) {
			if ($this->load((int)$id)) {
				return false;
			}
		}

		// Check for a id.
		if (empty($this->id)) {
			return true;
		}

		$user	= &JFactory::getUser();
		$query	= 'DELETE FROM #__lexicon_terms WHERE id = '.(int)$this->id;
		$this->_db->setQuery($query);

		if (!$this->_db->query()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		return true;
	}

	/**
	 * Inserts a new row if id is zero or updates an existing row in the database table
	 *
	 * @access	public
	 * @param	boolean $updateNulls	If false, null object variables are not updated
	 * @return	mixed	Boolean true if successful otherwise false and sets an error message
	 */
	function store($updateNulls = false)
	{
		$k = $this->_tbl_key;

		if($this->$k)
		{
			$ret = $this->_db->updateObject( $this->_tbl, $this, $this->_tbl_key, $updateNulls );
		}
		else
		{
			$ret = $this->_db->insertObject( $this->_tbl, $this, $this->_tbl_key );
		}

		if(!$ret)
		{
			$this->setError(get_class($this).'::store failed - '.$this->_db->getErrorMsg());
			return false;
		}

		return true;
	}
}