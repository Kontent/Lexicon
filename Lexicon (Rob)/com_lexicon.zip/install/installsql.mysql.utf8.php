-- <?php /* $Id$ */ defined('_JEXEC') or die ?>;

--
-- Table structure for table `#__lexicon_terms`
--

CREATE TABLE IF NOT EXISTS `#__lexicon_terms` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `singular` varchar(255) NOT NULL,
  `plural` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `state` tinyint(4) NOT NULL default '1',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(11) NOT NULL default '0',
  `created_by_alias` varchar(255) NOT NULL,
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `#__lexicon_content_map`
--

CREATE TABLE IF NOT EXISTS `#__lexicon_content_map` (
  `content_id` int(10) unsigned NOT NULL,
  `term_id` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`content_id`,`term_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
