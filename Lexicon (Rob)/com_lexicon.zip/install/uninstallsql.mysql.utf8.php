-- <?php /* $Id$ */ defined( '_JEXEC' ) or die() ?>

DROP TABLE IF EXISTS `#__lexicon_terms`;
