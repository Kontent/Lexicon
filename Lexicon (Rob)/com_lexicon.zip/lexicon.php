<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

require_once(JPATH_COMPONENT.DS.'controller.php');

// Execute the task.
$controller	= &LexiconController::getInstance();
$controller->execute(JRequest::getVar('task'));
$controller->redirect();