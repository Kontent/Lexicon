<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

/**
 * Terms controller class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconControllerTerms extends LexiconController
{
	/**
	 * Method to delete item(s) from the database.
	 *
	 * @since	1.0
	 * @access	public
	 * @return	void
	 */
	function delete()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Terms');
		$cid	= JRequest::getVar('cid', array(), 'post', 'array');

		// Sanitize the input.
		JArrayHelper::toInteger($cid);

		// Attempt to delete the terms.
		$return = $model->delete($cid);

		// Delete the terms
		if ($return === false)
		{
			$message = JText::sprintf('LEXICON_TERM_DELETE_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'error');
			return false;
		}
		else
		{
			$message = JText::_('LEXICON_TERM_DELETE_SUCCESS');
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message);
			return true;
		}
	}

	/**
	 * Method to publish unpublished item(s).
	 *
	 * @since	1.0
	 * @access	public
	 * @return	void
	 */
	function publish()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		$model	= &$this->getModel('Terms', 'LexiconModel');
		$cid	= JRequest::getVar('cid', null, 'post', 'array');

		JArrayHelper::toInteger($cid);

		// Check for items.
		if (count( $cid ) < 1) {
			$message = JText::_('LEXICON_PUBLISH_FAILED_SELECT_AN_ITEM');
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'warning');
			return false;
		}

		// Attempt to publish the items.
		$return = $model->setStates($cid, 1);

		if ($return === false)
		{
			$message = JText::sprintf('LEXICON_TERM_PUBLISH_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'error');
			return false;
		}
		else
		{
			$message = JText::_('LEXICON_TERM_PUBLISH_SUCCESS');
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message);
			return true;
		}
	}

	/**
	 * Method to unpublish published item(s).
	 *
	 * @since	1.0
	 * @access	public
	 * @return	void
	 */
	function unpublish()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		$model	= &$this->getModel('Terms', 'LexiconModel');
		$cid	= JRequest::getVar('cid', null, 'post', 'array');

		JArrayHelper::toInteger($cid);

		// Check for items.
		if (count($cid) < 1) {
			$message = JText::_('LEXICON_UNPUBLISH_FAILED_SELECT_AN_ITEM');
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'warning');
			return false;
		}

		// Attempt to unublish the items.
		$return = $model->setStates($cid, 0);

		if ($return === false)
		{
			$message = JText::sprintf('LEXICON_TERM_UNPUBLISH_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'error');
			return false;
		}
		else
		{
			$message = JText::_('LEXICON_TERM_UNPUBLISH_SUCCESS');
			$this->setRedirect('index.php?option=com_lexicon&view=terms', $message);
			return true;
		}
	}
}