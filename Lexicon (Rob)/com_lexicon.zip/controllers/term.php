<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

/**
 * Term controller class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconControllerTerm extends LexiconController
{
	/**
	 * Method to save the changes to the current term and return
	 * back to the term edit view.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function apply()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		// Initialize variables.
		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Term');
		$post	= JRequest::get('post');
		$data	= $post['jxform'];

		// Convert the base parameters to INI string.
		if (isset($post['jxformparams']) && is_array($post['jxformparams']))
		{
			$registry = new JRegistry();
			$registry->loadArray($post['jxformparams']);
			$data['params'] = $registry->toString();
		}

		// Convert the media parameters to INI string.
		if (isset($post['jxformmedia']) && is_array($post['jxformmedia']))
		{
			$registry = new JRegistry();
			$registry->loadArray($post['jxformmedia']);
			$data['media'] = $registry->toString();
		}

		// Unset variables that should not be edited.
		unset($data['id']);
		unset($data['created']);
		unset($data['created_by']);
		unset($data['created_by_alias']);
		unset($data['modified']);
		unset($data['modified_by']);
		unset($data['checked_out']);
		unset($data['checked_out_time']);
		unset($data['hits']);
		unset($data['items']);

		// Attempt to save the term.
		$return = $model->save($data);

		if ($return === false)
		{
			// Save failed, go back to the term and display a notice.
			$message = JText::sprintf('LEXICON_TERM_APPLY_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
			return false;
		}
		else
		{
			// Attempt to check-out the new term for editing and redirect.
			if (!$model->checkout($return))
			{
				// Check-out failed, go back to the list and display a notice.
				$message = JText::sprintf('LEXICON_TERM_CHECKOUT_FAILED', $model->getError());
				$this->setRedirect('index.php?option=com_lexicon&view=terms', $message, 'error');
				return false;
			}
			else
			{
				// Save succeeded, go back to the term and display a message.
				$app->setUserState('com_lexicon.edit.term.id', $return);
				$message = JText::_('LEXICON_TERM_APPLY_SUCCESS');
				$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message);
				return true;
			}
		}
	}

	/**
	 * Method to cancel the edit operation, check-in the checked-out
	 * term and go back to the term list view.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function cancel()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		// Initialize variables.
		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Term', 'LexiconModel');

		// Get the term id.
		$id = (int) $app->getUserState('com_lexicon.edit.term.id');

		// Attempt to check-in the current term.
		if ($id)
		{
			if (!$model->checkin($id))
			{
				// Check-in failed, go back to the term and display a notice.
				$message = JText::sprintf('LEXICON_TERM_CHECKIN_FAILED', $model->getError());
				$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
				return false;
			}
		}

		// Clean the session data and redirect.
		$app->setUserState('com_lexicon.edit.term.id', null);
		$this->setRedirect('index.php?option=com_lexicon&view=terms');
	}

	/**
	 * Method to checkout a term for editing.  If a different term
	 * was previously checked-out, the previous term will be checked
	 * in first.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function edit()
	{
		// Initialize variables.
		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Term', 'LexiconModel');
		$cid	= JRequest::getVar('cid', array(), 'post', 'array');

		// Get the previous term id (if any) and the current term id.
		$previous_id	= (int) $app->getUserState('com_lexicon.edit.term.id');
		$id		= (int) (count($cid) ? $cid[0] : JRequest::getInt('id'));

		// If term ids do not match, checkin previous term.
		if (($previous_id > 0) && ($id != $previous_id))
		{
			if (!$model->checkin($previous_id))
			{
				// Check-in failed, go back to the term and display a notice.
				$message = JText::sprintf('LEXICON_TERM_CHECKIN_FAILED', $model->getError());
				$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
				return false;
			}
		}

		// Attempt to check-out the new term for editing and redirect.
		if (!$model->checkout($id))
		{
			// Check-out failed, go back to the list and display a notice.
			$message = JText::sprintf('LEXICON_TERM_CHECKOUT_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&id='.$id, $message, 'error');
			return false;
		}
		else
		{
			// Check-out succeeded, push the new term id into the session.
			$app->setUserState('com_lexicon.edit.term.id', $id);
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1');
			return true;
		}
	}

	/**
	 * Method to get a fresh term form for creating a new term.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function createnew()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		// Initialize variables.
		$app = &JFactory::getApplication();

		// Prepare the session data and redirect.
		$app->setUserState('com_lexicon.edit.term.id', -1);
		$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1');
		return true;
	}

	/**
	 * Method to save the changes to the current term and return
	 * back to the term list view.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function save()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		// Initialize variables.
		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Term');
		$post	= JRequest::get('post');
		$data	= $post['jxform'];

		// Unset variables that should not be edited.
		unset($data['id']);
		unset($data['created']);
		unset($data['created_by']);
		unset($data['created_by_alias']);
		unset($data['modified']);
		unset($data['modified_by']);
		unset($data['checked_out']);
		unset($data['checked_out_time']);

		// Attempt to save the term.
		$return = $model->save($data);

		if ($return === false)
		{
			// Save failed, go back to the term and display a notice.
			$message = JText::sprintf('LEXICON_TERM_SAVE_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
			return false;
		}

		// Save succeeded, check-in the term.
		if (!$model->checkin())
		{
			// Check-in failed, go back to the term and display a notice.
			$message = JText::sprintf('LEXICON_TERM_CHECKIN_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
			return false;
		}

		// Clean the session data.
		$app->setUserState('com_lexicon.edit.term.id', null);

		$message = JText::_('LEXICON_TERM_SAVE_SUCCESS');
		$this->setRedirect('index.php?option=com_lexicon&view=terms', $message);
		return true;
	}

	/**
	 * Method to save the changes to the current term and return
	 * back to the term edit view with a clean form.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function savenew()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		// Initialize variables.
		$app	= &JFactory::getApplication();
		$model	= &$this->getModel('Term');
		$post	= JRequest::get('post');
		$data	= $post['jxform'];

		// Convert the base parameters to INI string.
		if (isset($post['jxformparams']) && is_array($post['jxformparams']))
		{
			$registry = new JRegistry();
			$registry->loadArray($post['jxformparams']);
			$data['params'] = $registry->toString();
		}

		// Convert the media parameters to INI string.
		if (isset($post['jxformmedia']) && is_array($post['jxformmedia']))
		{
			$registry = new JRegistry();
			$registry->loadArray($post['jxformmedia']);
			$data['media'] = $registry->toString();
		}

		// Unset variables that should not be edited.
		unset($data['id']);
		unset($data['created']);
		unset($data['created_by']);
		unset($data['created_by_alias']);
		unset($data['modified']);
		unset($data['modified_by']);
		unset($data['checked_out']);
		unset($data['checked_out_time']);
		unset($data['hits']);
		unset($data['items']);

		// Attempt to save the term.
		$return = $model->save($data);

		if ($return === false)
		{
			// Save failed, go back to the term and display a notice.
			$message = JText::sprintf('LEXICON_TERM_SAVE_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
			return false;
		}

		// Save succeeded, check-in the term.
		if (!$model->checkin())
		{
			// Check-in failed, go back to the term and display a notice.
			$message = JText::sprintf('LEXICON_TERM_CHECKIN_FAILED', $model->getError());
			$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message, 'error');
			return false;
		}

		// Prepare the session data.
		$app->setUserState('com_lexicon.edit.term.id', -1);

		$message = JText::_('LEXICON_TERM_SAVE_SUCCESS');
		$this->setRedirect('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1', $message);
		return true;
	}

	/**
	 * Method to view a term.
	 *
	 * @access	public
	 * @return	bool	False on failure or error, true on success.
	 * @since	1.0
	 */
	function view()
	{
		JRequest::checkToken() or jexit(JText::_('JX_INVALID_TOKEN'));

		$app		= &JFactory::getApplication();
		$model		= &$this->getModel('Term', 'LexiconModel');
		$cid		= JRequest::getVar('cid', array(), 'post', 'array');
		$id	= (int) (count($cid) ? $cid[0] : JRequest::getInt('id'));

		// Check-in the term just to be safe.
		$model->checkin($id);

		$app->setUserState('com_lexicon.view.term.id', $id);
		$this->setRedirect('index.php?option=com_lexicon&view=term&layout=default&id='.$id.'&hidemainmenu=1');
		return true;
	}
}