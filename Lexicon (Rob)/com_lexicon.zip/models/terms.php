<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.model');
jximport('jxtended.database.query');

/**
 * Terms model class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconModelTerms extends JModel
{
	/**
	 * Flag to indicate model state initialization.
	 *
	 * @access	private
	 * @var		boolean
	 */
	var $__state_set		= false;

	/**
	 * An array of counts for the lists.
	 *
	 * @access	protected
	 * @var		array
	 */
	var $_counts		= array();

	/**
	 * An array of totals for the lists.
	 *
	 * @access	protected
	 * @var		array
	 */
	var $_totals		= array();

	/**
	 * Array of lists containing items.
	 *
	 * @access	protected
	 * @var		array
	 */
	var $_lists			= array();

	/**
	 * Overridden method to get model state variables.
	 *
	 * @access	public
	 * @param	string	$property	Optional parameter name.
	 * @return	object	The property where specified, the state object where omitted.
	 * @since	1.0
	 */
	function getState($property = null)
	{
		// If the model state is uninitialized lets set some values we will need from the request.
		if (!$this->__state_set)
		{
			$app		= &JFactory::getApplication();
			$params		= &JComponentHelper::getParams('com_lexicon');
			$context	= 'com_lexicon.terms.';

			// Load the filter state.
			$this->setState('filter.search', $app->getUserStateFromRequest($context.'filter.search', 'filter_search', ''));
			$this->setState('filter.state', $app->getUserStateFromRequest($context.'filter.state', 'filter_state', 10, 'int'));

			// Load the list state.
			$this->setState('list.start', $app->getUserStateFromRequest($context.'list.start', 'limitstart', 0, 'int'));
			$this->setState('list.limit', $app->getUserStateFromRequest($context.'list.limit', 'limit', $app->getCfg('list_limit', 25), 'int'));
			$this->setState('list.ordering', $app->getUserStateFromRequest($context.'list.ordering', 'filter_order', 't.singular', 'cmd'));
			$this->setState('list.direction', $app->getUserStateFromRequest($context.'list.direction', 'filter_order_Dir', 'ASC', 'word'));

			// Handle 0 limit with > 0 start offset.
			if ($this->_state->get('list.limit') === 0) {
				$this->_state->set('list.start', 0);
			}

			// Load the parameters.
			$this->setState('params', $params);

			$this->__state_set = true;
		}

		return parent::getState($property);
	}

	/**
	 * Method to delete terms from the database.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	integer	$cid	An array of	numeric ids of the rows.
	 * @return	boolean	True on success/false on failure.
	 */
	function delete($cid)
	{
		// Add a table include path
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		// Get a term row instance
		$row = JTable::getInstance('Term', 'LexiconTable');

		for($i = 0, $c = count($cid); $i < $c; $i++)
		{
			// Load the row.
			$return = $row->load($cid[$i]);

			// Check for an error.
			if ($return == false) {
				$this->setError($row->getError());
				return false;
			}

			// Delete the row.
			$return = $row->delete();

			// Check for an error.
			if ($return == false) {
				$this->setError($row->getError());
				return false;
			}
		}

		return true;
	}

	/**
	 * Method to get a list of items.
	 *
	 * @access	public
	 * @return	mixed	An array of objects on success, false on failure.
	 * @since	1.0
	 */
	function &getTerms()
	{
		// Get a unique key for the current list state.
		$key	= $this->_getStoreId('lexicon.terms');
		$false	= false;

		// Try to load the value from internal storage.
		if (!empty ($this->_lists[$key])) {
			return $this->_lists[$key];
		}

		// Load the list.
		$query	= $this->_getListQuery();
		$rows	= $this->_getList($query->toString(), $this->getState('list.start'), $this->getState('list.limit'));

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return $false;
		}

		// Add the rows to the internal storage.
		$this->_lists[$key] = $rows;

		return $this->_lists[$key];
	}

	/**
	 * Method to get a list pagination object.
	 *
	 * @access	public
	 * @return	object	A JPagination object.
	 * @since	1.0
	 */
	function &getPagination()
	{
		if (!empty($this->_pagination)) {
			return $this->_pagination;
		}

		jimport('joomla.html.pagination');
		$this->_pagination = new JPagination($this->getCount(), $this->getState('list.start'), $this->getState('list.limit'));

		return $this->_pagination;
	}

	/**
	 * Method to get the total number of items.
	 *
	 * @access	public
	 * @return	int		The number of items.
	 * @since	1.0
	 */
	function getTotal()
	{
		// Get a unique key for the current list state.
		$key = $this->_getStoreId('lexicon.terms');

		// Try to load the value from internal storage.
		if (!empty ($this->_totals[$key])) {
			return $this->_totals[$key];
		}

		// Load the total.
		$this->_db->setQuery('SELECT count(id) FROM #__lexicon_terms');
		$return = (int)$this->_db->loadResult();

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Push the value into internal storage.
		$this->_totals[$key] = $return;

		return $this->_totals[$key];
	}

	/**
	 * Method to get the number of items for the list configuration.
	 *
	 * @access	public
	 * @return	int		The number of items.
	 * @since	1.0
	 */
	function getCount()
	{
		// Get a unique key for the current list state.
		$key = $this->_getStoreId('lexicon.terms');

		// Try to load the value from internal storage.
		if (!empty ($this->_counts[$key])) {
			return $this->_counts[$key];
		}

		// Load the count.
		$query	= $this->_getListQuery();
		$return	= (int)@$this->_getListCount($query->toString());

		// Check for a database error.
		if ($this->_db->getErrorNum()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Push the value into internal storage.
		$this->_counts[$key] = $return;

		return $this->_counts[$key];
	}

	/**
	 * Method to save the current ordering of all terms.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	array	$cid	The numeric row ids.
	 * @param	array	$order	The numeric ordering for each row.
	 * @return	boolean	True on success/false on failure.
	 */
	function saveorder($cid, $order)
	{
		// Add a table include path
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		// Get a term row instance.
		$row = JTable::getInstance('Term', 'LexiconTable');

		// Update the ordering for each row
		for ($i=0; $i < count($cid); $i++)
		{
			// Load the row
			$row->load($cid[$i]);

			// Check the current ordering
			if ($row->ordering != $order[$i])
			{
				// Set the new ordering
				$row->ordering = $order[$i];

				// Save the row
				if (!$row->store()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
		}

		return true;
	}

	function setStates($cid, $state = 0)
	{
		$user = &JFactory::getUser();

		// Add a table include path.
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		// Get a term row instance.
		$row = JTable::getInstance('Term', 'LexiconTable');

		// Update the state for each row
		for ($i=0; $i < count($cid); $i++)
		{
			// Load the row.
			$row->load($cid[$i]);

			// Make sure the term isn't checked out by someone else.
			if ($row->checked_out != 0 && $row->checked_out != $user->id)
			{
				$this->setError(JText::sprintf('LEXICON_TERM_CHECKED_OUT', $cid[$i]));
				return false;
			}

			// Check the current ordering.
			if ($row->state != $state)
			{
				// Set the new ordering.
				$row->state = $state;

				// Save the row.
				if (!$row->store()) {
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @access	protected
	 * @return	string		An SQL query
	 * @since	1.0
	 */
	function _getListQuery()
	{
		$query = new JXQuery();

		// Select all fields from the table.
		$query->select('t.*');
		$query->from('`#__lexicon_terms` AS t');


		// If the model is set to check item state, add to the query.
		if ($this->getState('check.state', true)) {
			$query->where('t.state = '.(int)$this->getState('filter.state'));
		}

		// Filter the comments over the search string if set.
		$search = $this->getState('filter.search');
		if (!empty($search)) {
			$query->where('t.singular LIKE '.$this->_db->Quote('%'.$search.'%').' OR t.body LIKE '.$this->_db->Quote('%'.$search.'%'));
		}

		// Add the list ordering clause.
		$query->order($this->_db->getEscaped($this->getState('list.ordering').' '.$this->getState('list.direction')));

		//echo nl2br(str_replace('#__','jos_',$query->toString())).'<hr/>';
		return $query;
	}

	/**
	 * Method to get a store id based on model configuration state.
	 *
	 * This is necessary because the model is used by the component and
	 * different modules that might need different sets of data or different
	 * ordering requirements.
	 *
	 * @access	protected
	 * @param	string		$id		A prefix for the store id.
	 * @return	string		A store id.
	 * @since	1.0
	 */
	function _getStoreId($id = '')
	{
		// Compile the store id.
		$id	.= ':'.$this->getState('list.start');
		$id	.= ':'.$this->getState('list.limit');
		$id	.= ':'.$this->getState('list.ordering');
		$id	.= ':'.$this->getState('list.direction');
		$id	.= ':'.$this->getState('check.state');
		$id	.= ':'.$this->getState('filter.state');
		$id	.= ':'.$this->getState('filter.search');
		$id	.= ':'.$this->getState('filter.context');
		$id	.= ':'.$this->getState('filter.thread_id');

		return md5($id);
	}
}