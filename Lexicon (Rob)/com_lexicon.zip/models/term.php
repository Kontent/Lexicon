<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.model');

/**
 * Term model class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconModelTerm extends JModel
{
	/**
	 * Flag to indicate model state initialization.
	 *
	 * @access	private
	 * @var		boolean
	 */
	var $__state_set		= false;

	/**
	 * Overridden method to get model state variables.
	 *
	 * @access	public
	 * @param	string	$property	Optional parameter name.
	 * @return	object	The property where specified, the state object where omitted.
	 * @since	1.0
	 */
	function getState($property = null)
	{
		// If the model state is uninitialized lets set some values we will need from the request.
		if (!$this->__state_set)
		{
			$app		= &JFactory::getApplication();
			$params		= JComponentHelper::getParams('com_lexicon');

			// Load the term state.
			if (JRequest::getWord('layout') === 'edit') {
				$id = (int)$app->getUserState('com_lexicon.edit.term.id');
				$this->setState('term.id', $id);
			} else {
				$id = (int)JRequest::getInt('id');
				$this->setState('term.id', $id);
			}

			// Load the parameters.
			$this->setState('params', $params);

			$this->__state_set = true;
		}

		return parent::getState($property);
	}

	/**
	 * Method to checkin a row.
	 *
	 * @since	1.0
	 * @access	public
	 * @param	integer	$id		The numeric id of a row
	 * @return	boolean	True on success/false on failure
	 */
	function checkin($id = null)
	{
		// Initialize variables.
		$user		= &JFactory::getUser();
		$user_id	= (int) $user->get('id');
		$id	= (int) $id;

		if ($id === 0) {
			$id = $this->getState('term.id');
		}

		if (!$id) {
			return true;
		}

		// Get a LexiconTableTerm instance.
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row = &JTable::getInstance('Term', 'LexiconTable');

		// Attempt to check-in the row.
		$return = $row->checkin($user_id, $id);

		// Check for a database error.
		if ($return === false) {
			$this->setError($row->getError());
			return false;
		}

		return true;
	}

	/**
	 * Method to check-out a term for editing.
	 *
	 * @access	public
	 * @param	int		$id	The numeric id of the term to check-out.
	 * @return	bool	False on failure or error, success otherwise.
	 * @since	1.0
	 */
	function checkout($id)
	{
		// Initialize variables.
		$user		= &JFactory::getUser();
		$user_id	= (int) $user->get('id');
		$id	= (int) $id;

		// Check for a new term id.
		if ($id === -1) {
			return true;
		}

		// Get a LexiconTableTerm instance.
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row = &JTable::getInstance('Term', 'LexiconTable');

		// Attempt to check-out the row.
		$return = $row->checkout($user_id, $id);

		// Check for a database error.
		if ($return === false) {
			$this->setError($row->getError());
			return false;
		}

		// Check if the row is checked-out by someone else.
		if ($return === null) {
			$this->setError(JText::_('LEXICON_TERM_CHECKED_OUT'));
			return false;
		}

		return true;
	}

	/**
	 * Method to get the form object.
	 *
	 * @access	public
	 * @param	string	$type	The type of form to load (view, model);
	 * @return	mixed	JXForm object on success, false on failure.
	 * @since	1.0
	 */
	function &getForm($type = 'view')
	{
		$false = false;

		// Load the form library.
		jximport('jxtended.form.helper');
		JXFormHelper::addIncludePath(JPATH_COMPONENT.DS.'models');

		if ($type == 'model') {
			$result = &JXFormHelper::getModel('term');
		} else {
			$result = &JXFormHelper::getView('term');
		}

		// Check for an error.
		if (JError::isError($result)) {
			$this->setError($result->getMessage());
			return $false;
		}

		return $result;
	}

	/**
	 * Method to get a term.
	 *
	 * @access	public
	 * @return	mixed	Object on successful load, false on error, null otherwise.
	 * @since	1.0
	 */
	function &getTerm()
	{
		// Initialize variables.
		$id	= (int) $this->getState('term.id');
		$false		= false;
		$null		= null;

		// Get a LexiconTableTerm instance.
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row = &JTable::getInstance('Term', 'LexiconTable');

		// Attempt to load the row.
		$return = $row->load($id);

		// Check for a database error.
		if ($return === false && $row->getError()) {
			$this->serError($row->getError());
			return $false;
		}

		return $row;
	}

		/**
	 * Method to adjust the ordering of a row.
	 *
	 * @access	public
	 * @param	int		$id	The numeric id of the term to move.
	 * @param	int		$direction	The direction to move the row (-1/1).
	 * @return	bool	True on success/false on failure
	 * @since	1.0
	 */
	function move($id, $direction)
	{
		// Get a LexiconTableTerm instance.
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');
		$row = &JTable::getInstance('Term', 'LexiconTable');

		// Attempt to check-out and move the row.
		if (!$this->checkout($id)) {
			return false;
		}

		// Load the row.
		if (!$row->load($id)) {
			$this->setError($row->getError());
			return false;
		}

		// Move the row.
		$row->move($direction);

		// Check-in the row.
		if (!$this->checkin($id)) {
			return false;
		}

		return true;
	}

	function save($data)
	{
		$id		= (int)$this->getState('term.id');
		$isNew	= true;

		// Add a table include path
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');

		// Get a term row instance.
		$row = JTable::getInstance('Term', 'LexiconTable');

		// Load the row if saving an existing item.
		if ($id > 0)
		{
			$row->load($id);
			$isNew = false;
		}

		// Bind the data
		if (!$row->bind($data))
		{
			$this->setError(JText::sprintf('LEXICON_TERM_BIND_FAILED', $row->getError()));
			return false;
		}

		// Prepare the row for saving
		$row = $this->_prepareSave($row);

		// Check the data
		if (!$row->check())
		{
			$this->setError($row->getError());
			return false;
		}

		// Store the data
		if (!$row->store())
		{
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		return $row->id;
	}

	function _prepareSave($row)
	{
		$date = &JFactory::getDate();
		$user = &JFactory::getUser();

		// Set created/modification data.
		if (!$row->id) {
			// Set the values
			$row->created			= $date->toMySQL();
			$row->created_by		= $user->get('id');
			$row->created_by_alias	= $user->get('name');
		}
		else {
			// Set the values
			$row->modified		= $date->toMySQL();
			$row->modified_by	= $user->get('id');
		}

		return $row;
	}
}