<?php
/**
 * @version		$Id: edit.php 308 2008-12-11 22:02:48Z louis $
 * @package		JXtended.Labels
 * @subpackage	com_labels
 * @copyright	(C) 2008 JXtended, LLC. All rights reserved.
 * @license		GNU General Public License.
 * @link		http://jxtended.com
 */

defined('_JEXEC') or die;

JHtml::addIncludePath(JPATH_COMPONENT.DS.'helpers'.DS.'html');
JHtml::stylesheet('default.css', 'components/com_lexicon/media/css/');
JHtml::_('behavior.tooltip');
JHtml::_('behavior.formvalidation');

// Get the form fields.
$fieldsMain		= $this->form->getFields('jxform');
$fieldsAccess	= $this->form->getFields('jxform', 'access');
$fieldsDetails	= $this->form->getFields('jxform', 'details');
$fieldsEditors	= $this->form->getFields('jxform', 'editors');

// Get the user's editor.
$editor = &JFactory::getEditor();

$this->document->addScriptDeclaration("
	function submitbutton(pressbutton)
	{
		// Bypass form validation if the cancel button was pressed.
		if (pressbutton == 'term.cancel') {
			submitform(pressbutton);
			return;
		}

		// Check if the form is valid.
		form = $('".$this->form->getId()."-form');
		if (document.formvalidator.isValid(form)){
			".$editor->save('jxform[body]')."
			submitform(pressbutton);
		}
	}"
);
?>

<?php echo $this->form->getHead(); ?>

	<div class="col width-100" style="width: 100%">
		<table class="adminform">
			<tbody>
				<tr>
					<td>
						<strong><?php echo $fieldsMain['singular']->label; ?>:</strong><br />
						<?php echo $fieldsMain['singular']->field; ?>
					</td>
					<td>
						<strong><?php echo $fieldsMain['plural']->label; ?>:</strong><br />
						<?php echo $fieldsMain['plural']->field; ?>
					</td>
					<td>
						<strong><?php echo $fieldsDetails['created']->label; ?></strong><br />
						<?php echo $fieldsDetails['created']->field; ?>
					</td>
					<td>
						<strong><?php echo $fieldsDetails['state']->label; ?></strong><br />
						<?php echo $fieldsDetails['state']->field; ?>
					</td>
				</tr>
			</tbody>
		</table>

		<table width="100%">
			<tbody>
				<tr valign="top">
					<td width="60%">
						<fieldset>
							<legend><?php echo $fieldsEditors['body']->label; ?></legend>

							<?php echo $fieldsEditors['body']->field; ?><br /><br />
						</fieldset>
					</td>
					<td width="40%">

					</td>
				</tr>
			</tbody>
		</table>
	</div>

	<input type="hidden" name="option" value="com_lexicon" />
	<input type="hidden" name="task" value="display" />
	<input type="hidden" name="view" value="term" />
	<input type="hidden" name="layout" value="edit" />
	<?php echo JHtml::_('form.token'); ?>
<?php echo $this->form->getFoot(); ?>