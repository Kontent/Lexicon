<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

/**
 * Term view class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconViewTerm extends JView
{
	/**
	 * Method to display the view.
	 *
	 * @access	public
	 * @param	string	$tpl	A template file to load.
	 * @since	1.0
	 */
	function display($tpl = null)
	{
		// Load the view data.
		$form		= &$this->get('Form');
		$term		= &$this->get('Term');
		$user		= &JFactory::getUser();
		$state		= $this->get('State');
		$params		= $state->get('params');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		// Prepare the form.
		if ($form) {
			$form->setName('adminForm');
			$form->setAction(JRoute::_('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1'));
			$form->loadObject($term);
		}

		// Setup the toolbar.
		$this->_setupToolbar();

		// Push out the view data.
		$this->assignRef('form', $form);
		$this->assignRef('term', $term);
		$this->assignRef('user', $user);
		$this->assign('state', $state);
		$this->assign('params', $params);

		parent::display($tpl);
	}

	/**
	 * Method to setup the view toolbar.
	 *
	 * @access	private
	 * @return	void
	 * @since	1.0
	 */
	function _setupToolbar()
	{
		JToolBarHelper::title(JText::_('LEXICON_EDIT_TERM_TOOLBAR_TITLE'), 'lexicon');
		$toolbar = &JToolBar::getInstance('toolbar');
		$toolbar->addButtonPath(JPATH_COMPONENT.DS.'helpers'.DS.'html'.DS.'toolbar'.DS.'button');
		$toolbar->appendButton('Standard', 'new', 'LEXICON_SAVENEW', 'term.savenew', false, false);
		$toolbar->appendButton('Separator', 'divider');
		$toolbar->appendButton('Standard', 'save', 'SAVE', 'term.save', false, false);
		$toolbar->appendButton('Standard', 'apply', 'APPLY', 'term.apply', false, false);
		$toolbar->appendButton('Standard', 'cancel', 'CANCEL', 'term.cancel', false, false);
	}
}