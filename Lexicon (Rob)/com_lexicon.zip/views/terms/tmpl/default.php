<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

JHtml::addIncludePath(JPATH_COMPONENT.DS.'helpers'.DS.'html');
JHtml::addIncludePath(JPATH_SITE.DS.'plugins'.DS.'system'.DS.'jxtended'.DS.'html'.DS.'html');
JHtml::stylesheet('default.css', 'components/com_lexicon/media/css/');
?>

<form action="index.php?option=com_lexicon&amp;view=terms" method="post" name="adminForm">
	<div class="form-filter" style="float: left;">
		<label for="filter_search"><?php echo JText::sprintf('LEXICON_SEARCH_TERMS', JText::_('TERMS')); ?></label>
		<input type="text" name="filter_search" id="filter_search" value="<?php echo $this->state->get('filter.search'); ?>" class="text_area" onchange="document.adminForm.submit();" title="<?php echo JText::_('LEXICON_SEARCH_TERMS');?>"/>
		<button onclick="this.form.submit();"><?php echo JText::_('LEXICON_SEARCH_GO'); ?></button>
		<button onclick="document.getElementById('filter_search').value='';document.getElementById('filter_state').value='10';this.form.submit();"><?php echo JText::_('LEXICON_SEARCH_RESET'); ?></button>
	</div>

	<table class="adminlist" style="clear: both;">
		<thead>
			<tr>
				<th width="5">
					<?php echo JText::_('NUM'); ?>
				</th>
				<th width="5">
					<input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo (count($this->terms)+1); ?>);" />
				</th>
				<th nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'LEXICON_TERM_SINGULAR', 't.singular', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?>
				</th>
				<th nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'LEXICON_TERM_PLURAL', 't.plural', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?>
				</th>
				<th width="4%" nowrap="nowrap" style="padding: 0px 15px;">
					<?php echo JHTML::_('grid.sort', 'LEXICON_TERM_STATE', 't.state', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?>
				</th>
				<th align="center" width="7%" style="padding: 0px 15px;" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'LEXICON_TERM_AUTHOR', 't.created_by_alias', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?>
				</th>
				<th align="center" width="10%" style="padding: 0px 15px;" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', 'LEXICON_TERM_TIMESTAMP', 't.created', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?>
				</th>
			</tr>
		</thead>
		<tbody>
			<?php if (count($this->terms) == 0): ?>
			<tr class="row0">
				<td align="center" colspan="11">
					<?php
					if ($this->total == 0):
						echo JText::_('LEXICON_NO_TERMS');
						?>
						<a href="<?php echo JRoute::_('index.php?option=com_lexicon&view=term&layout=edit&hidemainmenu=1'); ?>" title="<?php echo JText::_('LEXICON_CREATE_TERM'); ?>">
							<?php echo JText::_('LEXICON_CREATE_TERM'); ?>
						</a>
						<?php
					else:
						echo JText::_('LEXICON_NO_RESULTS');
					endif;
					?>
				</td>
			</tr>
			<?php endif; ?>

			<?php $n = 0; $o = 0; $c = count($this->terms); ?>
			<?php foreach ($this->terms as $term): ?>

			<tr class="<?php echo 'row', $o; ?>">
				<td>
					<?php echo $n+1+$this->state->get('list.start'); ?>
				</td>
				<td align="center">
					<?php echo JHTML::_('grid.checkedOut', $term, $n); ?>
				</td>
				<td style="padding-left: 10px; padding-right: 10px;">
					<?php $term->url = JURI::base().'index.php?option=com_lexicon&task=term.edit&id='.$term->id; ?>
					<a href="<?php echo $term->url; ?>" title="<?php echo $term->singular; ?>"><?php echo $term->singular; ?></a>
				</td>
				<td style="padding-left: 10px; padding-right: 10px;">
					<?php $term->url = JURI::base().'index.php?option=com_lexicon&task=term.edit&id='.$term->id; ?>
					<a href="<?php echo $term->url; ?>" title="<?php echo $term->plural; ?>"><?php echo $term->plural; ?></a>
				</td>
				<td nowrap="nowrap" style="padding: 0px 20px; text-align: center">
					<?php echo JHTML::_('jxgrid.published', $n, $term->state, 'terms.'); ?>
				</td>
				<td nowrap="nowrap" style="padding: 0px 20px; text-align: center">
					<?php echo $term->created_by_alias; ?>
				</td>
				<td nowrap="nowrap" style="padding: 0px 20px; text-align: center">
					<?php
						$date = &JFactory::getDate($term->created);
						$date->setOffset($this->user->_params->get('timezone'));

						echo $date->toFormat();
					?>
				</td>
			</tr>

			<?php $n++; $o = ++$o % 2; ?>
			<?php endforeach; ?>
		</tbody>
		<tfoot>
			<tr>
				<td colspan="11" nowrap="nowrap">
					<?php echo $this->pagination->getListFooter(); ?>
				</td>
			</tr>
		</tfoot>
	</table>

	<input type="hidden" name="option" value="com_lexicon" />
	<input type="hidden" name="task" value="display" />
	<input type="hidden" name="view" value="terms" />
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" name="filter_order" value="<?php echo $this->state->get('list.ordering'); ?>" />
	<input type="hidden" name="filter_order_Dir" value="<?php echo $this->state->get('list.direction'); ?>" />
	<?php echo JHTML::_('form.token'); ?>
</form>