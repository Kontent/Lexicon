<?php
/**
 * @version		$Id$
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @copyright	Copyright (C) 2008 Rob Schley. All rights reserved.
 * @license		GNU General Public License
 */

defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.view');

/**
 * Terms view class for Lexicon.
 *
 * @package		Lexicon
 * @subpackage	com_lexicon
 * @version		1.0
 */
class LexiconViewTerms extends JView
{
	/**
	 * Method to display the view.
	 *
	 * @access	public
	 * @param	string	$tpl	A template file to load.
	 * @since	1.0
	 */
	function display($tpl = null)
	{
		// Load the view data.
		$terms		= &$this->get('Terms');
		$pagination	= &$this->get('Pagination');
		$user		= &JFactory::getUser();
		$total		= $this->get('Total');
		$state		= $this->get('State');
		$params		= $state->get('params');

		// Check for errors.
		if (count($errors = $this->get('Errors'))) {
			JError::raiseError(500, implode("\n", $errors));
			return false;
		}

		// Setup the toolbar.
		$this->_setupToolbar();

		// Push out the view data.
		$this->assignRef('terms', $terms);
		$this->assignRef('pagination', $pagination);
		$this->assignRef('user', $user);
		$this->assign('total', $total);
		$this->assign('state', $state);
		$this->assign('params', $params);

		parent::display($tpl);
	}

	/**
	 * Method to setup the view toolbar.
	 *
	 * @access	private
	 * @return	void
	 * @since	1.0
	 */
	function _setupToolbar()
	{
		JToolBarHelper::title(JText::_('LEXICON_TERMS_TOOLBAR_TITLE'), 'lexicon');
		$toolbar = &JToolBar::getInstance('toolbar');
		$toolbar->addButtonPath(JPATH_COMPONENT.DS.'helpers'.DS.'html'.DS.'toolbar'.DS.'button');
		$toolbar->appendButton('Standard', 'publish', 'Publish', 'terms.publish', true, false);
		$toolbar->appendButton('Standard', 'unpublish', 'Unpublish', 'terms.unpublish', true, false);
		$toolbar->appendButton('Separator', 'divider');
		$toolbar->appendButton('Standard', 'new', 'New', 'term.createnew', false, false);
		$toolbar->appendButton('Standard', 'edit', 'Edit', 'term.edit', true, false);
		$toolbar->appendButton('Confirm', 'LEXICON_TERMS_DELETE_CONFIRMATION', 'delete', 'Delete', 'terms.delete', true, false);
	}
}